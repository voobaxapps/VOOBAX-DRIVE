"""Lightweight patch smoke tests. Does NOT test Android Auto projection or compile an APK."""
import importlib.util
import tempfile
from pathlib import Path
import unittest
import xml.etree.ElementTree as ET

SRC = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('apply_voobax', SRC / 'apply_voobax.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class TestPatch(unittest.TestCase):
    def test_preserves_formats_plurals_and_markup(self):
        with tempfile.TemporaryDirectory() as folder:
            res = Path(folder)
            (res / 'values').mkdir()
            original = '<resources><string name="count">Count: %1$d</string><string name="quoted">Original</string><string name="rich"><b>Bold</b></string><plurals name="items"><item quantity="other">%d items</item></plurals></resources>'
            (res / 'values/strings.xml').write_text(original)
            mod.localize(res, {'count': 'Sayı', 'quoted': "It's fine", 'rich': 'Plain'})
            result = (res / 'values/strings.xml').read_text()
            self.assertIn('Count: %1$d', result)
            self.assertIn('<b>Bold</b>', result)
            self.assertIn('<plurals name="items"><item quantity="other">%d items</item></plurals>', result)
            self.assertIn("It\\'s fine", result)
            localized = (res / 'values-az/strings.xml').read_text()
            self.assertNotIn('name="count"', localized)

    def test_apply_to_upstream_structure(self):
        with tempfile.TemporaryDirectory() as folder:
            dest = Path(folder)
            (dest / 'LICENSE').write_text('GNU AFFERO GENERAL PUBLIC LICENSE v3')
            (dest / 'app').mkdir()
            (dest / 'app/build.gradle.kts').write_text('applicationId = "com.andrerinas.headunitrevived"\nversionName = "3.5.0"')
            main = dest / 'app/src/main'
            (main / 'res/values').mkdir(parents=True)
            (main / 'res/values/strings.xml').write_text('<resources><string name="title">Open Headunit</string><string name="settings">Settings</string><string name="settings_tab_basic">Basic</string></resources>')
            (main / 'AndroidManifest.xml').write_text('<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application android:icon="@mipmap/ic_launcher"><activity android:name=".main.MainActivity" android:exported="true"/></application></manifest>')
            (main / 'res/xml').mkdir()
            (main / 'res/xml/shortcuts.xml').write_text('<shortcuts><intent android:targetPackage="com.andrerinas.headunitrevived"/></shortcuts>')
            mod.apply(dest)
            m = (main / 'AndroidManifest.xml').read_text()
            self.assertIn('com.voobax.drive.DiagnosticsActivity', m)
            self.assertIn('@mipmap/ic_voobax', m)
            ET.fromstring(m)
            self.assertIn('applicationId = "com.voobax.drive"', (dest / 'app/build.gradle.kts').read_text())
            self.assertIn('android:targetPackage="com.voobax.drive"', (main / 'res/xml/shortcuts.xml').read_text())
            self.assertTrue((main / 'res/mipmap-xhdpi/ic_voobax.png').is_file())
            ET.parse(main / 'res/values/strings.xml')
            ET.parse(main / 'res/values-az/strings.xml')
            self.assertTrue((main / 'java/com/voobax/drive/DiagnosticsActivity.java').is_file())
            self.assertTrue((dest / 'VOOBAX_DERIVATIVE_LICENSE.txt').is_file())

if __name__ == '__main__': unittest.main()
