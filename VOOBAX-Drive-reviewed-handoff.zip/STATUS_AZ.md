# İcra vəziyyəti

- Açılmış repozitoriya: https://github.com/voobaxapps/VOOBAX-DRIVE (public, main).
- Oxunan başlanğıc commit: 8978e0ee88065a386033ea47995c1660bac11aba.
- Upstream v.3.5.0 sabitlənib: 1c1b5b7261ebebde8000778ff2c06e3af3e3a326.
- `python3 -m unittest discover -s tests -v`: 2 test keçdi.
- Upstream-in həqiqi values/strings.xml faylı ilə ayrıca yoxlama: 136 tərcümə tətbiq olundu.
- Diaqnostika, mətn, ikon və workflow dəyişiklikləri lokal hazırdır.

## Maneələr

1. Upstream `git clone` cəhdi: `Failed to connect to proxy port 8080 ... Could not connect to server`. Mənbənin seçilmiş mətn faylları GitHub inteqrasiyası ilə oxunaraq yoxlandı; tam mənbə lokal endirilməyib.
2. GitHub `create_blob` ilə ilk ikonun yazılması cəhdi HTTP 403 qaytardı: `Resource not accessible by integration`. Uzaqda commit və ya branch yaradılmadı.
3. `gh auth status`: `The token in GH_TOKEN is invalid`. Terminal vasitəsilə alternativ yazma/yığım yolu da əlçatan deyil.

## Bərpa

ChatGPT GitHub bağlantısının VOOBAX-DRIVE repozitoriyası üçün Contents və Workflows yazma icazələrini aktivləşdirin / bağlantını yeniləyin. Alternativ olaraq, bu qovluğun məzmununu (gizli .github daxil) repozitoriyanın main branch-inə yükləyin. Push workflow-u avtomatik başladır. Hər halda APK-ni yalnız Actions uğurla bitdikdən sonra hazır saymaq olar.

APK kompilyasiya edilməyib; APK ölçüsü və SHA-256 mövcud deyil. Actions run və artefakt yaradılmayıb. AndroidManifest/resurs kompilyasiyası, emulator və real avtomobil sınağı aparılmayıb. Tam Android Auto funksionallığı təsdiqlənməyib. CarPlay daxil deyil.
