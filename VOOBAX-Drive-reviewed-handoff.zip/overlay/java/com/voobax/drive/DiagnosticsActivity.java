/*
 * VOOBAX Drive - Connection Diagnostics
 * Copyright (C) 2026 VOOBAX Drive contributors
 * SPDX-License-Identifier: AGPL-3.0-only
 */
package com.voobax.drive;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** No tracking, no network requests, no third-party dependencies. */
@SuppressWarnings("deprecation")
public class DiagnosticsActivity extends Activity {
    private static final int BACKGROUND = 0xFF0A1323;
    private static final int PANEL = 0xFF14243A;
    private static final int TEXT = 0xFFF3F7FD;
    private static final int SECONDARY = 0xFFA9BCD2;
    private static final int ACCENT = 0xFF22D3CE;
    private LinearLayout root;
    private String latestReport = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(BACKGROUND);
            getWindow().setNavigationBarColor(BACKGROUND);
        }
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView label(String str, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(str); t.setTextColor(color);
        t.setTextSize(size); t.setGravity(Gravity.START);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void card(String title, String value, String hint) {
        LinearLayout item = new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL);
        item.setPadding(dp(18), dp(14), dp(18), dp(14)); item.setBackground(bg(PANEL, 14));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, dp(10)); root.addView(item, p);
        item.addView(label(title, 14, SECONDARY, false));
        item.addView(label(value, 19, TEXT, true));
        if (hint != null) item.addView(label(hint, 12, SECONDARY, false));
    }
    private void action(String title, final String androidAction) {
        Button b = new Button(this); b.setText(title); b.setTextColor(BACKGROUND); b.setAllCaps(false);
        b.setBackground(bg(ACCENT, 12));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(52)); p.setMargins(0, 0, 0, dp(9));
        root.addView(b, p);
        b.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            try {
                Intent i = new Intent(androidAction);
                if (Settings.ACTION_APPLICATION_DETAILS_SETTINGS.equals(androidAction)) i.setData(Uri.parse("package:" + DiagnosticsActivity.this.getPackageName()));
                startActivity(i);
            }
            catch (Exception ex) { Toast.makeText(DiagnosticsActivity.this, "Bu ayar cihazda mövcud deyil", Toast.LENGTH_LONG).show(); }
        }});
    }
    @Override public void onResume() {
        super.onResume();
        render();
    }
    private void render() {
        ScrollView sc = new ScrollView(this); sc.setFillViewport(true); sc.setBackgroundColor(BACKGROUND);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(24)); sc.addView(root);
        setContentView(sc);
        TextView title = label("VOOBAX  /  BAĞLANTI MƏRKƏZİ", 25, TEXT, true);
        root.addView(title);
        TextView sub = label("Android Auto üçün şəbəkə və monitor diaqnostikası", 14, ACCENT, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.setMargins(0, dp(5), 0, dp(18)); root.addView(sub, sp);

        card("İlk simsiz qoşulma", "Avtomobil dayanarkən quraşdırın",
            "Telefonda Android Auto, Wi-Fi və Bluetooth-u aktiv edin. Monitorla telefonu cütləşdirin. "
            + "VOOBAX Drive ayarlarında Native Mode seçin və sistemin istədiyi yaxın cihazlar, "
            + "Bluetooth və məkan icazələrini verin. Android Auto təsdiqini telefonda tamamlayın. "
            + "Qoşulma üsulu cihazın dəstəyindən asılıdır. CarPlay dəstəklənmir.");
        WifiManager wm = (WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        String wifi = "Məlum deyil";
        String details = "Wi-Fi qoşulması monitorun sistemindən asılıdır";
        try {
            if (wm != null) {
                boolean on = wm.isWifiEnabled(); wifi = on ? "Aktiv" : "Deaktiv";
                if (on) {
                    WifiInfo info = wm.getConnectionInfo();
                    if (info != null && info.getNetworkId() != -1) {
                        int frequency = Build.VERSION.SDK_INT >= 21 ? info.getFrequency() : 0;
                        String band = frequency >= 4900 ? "5 GHz" : (frequency > 0 ? "2.4 GHz" : "Naməlum diapazon");
                        details = band + " · Siqnal: " + info.getRssi() + " dBm";
                    } else details = "Aktiv, əlaqə məlumatı yoxdur";
                }
            }
        } catch (SecurityException ex) { details = "Wi-Fi məlumatına giriş məhdudlaşdırılıb"; }
        card("Wi-Fi", wifi, details);

        String bt = "Məlum deyil";
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            bt = adapter == null ? "Bluetooth yoxdur" : (adapter.isEnabled() ? "Aktiv" : "Deaktiv");
        } catch (SecurityException ex) { bt = "İcazə tələb olunur"; }
        card("Bluetooth", bt, "İlk cütləşmə üçün Bluetooth vacib ola bilər");

        String mic = checkSelfPermissionCompat(Manifest.permission.RECORD_AUDIO) ? "İcazə verilib" : "İcazə verilməyib";
        String loc = checkSelfPermissionCompat(Manifest.permission.ACCESS_FINE_LOCATION) ? "İcazə verilib" : "İcazə verilməyib";
        card("Mikrofon", mic, "Zəng və səsli idarəetmə üçün istifadə olunur");
        card("Məkan icazəsi", loc, "Bəzi Android versiyalarında Wi-Fi Direct üçün vacibdir");
        if (Build.VERSION.SDK_INT >= 31) {
            card("Bluetooth bağlantı icazəsi", checkSelfPermissionCompat("android.permission.BLUETOOTH_CONNECT") ? "İcazə verilib" : "İcazə verilməyib", null);
        }
        if (Build.VERSION.SDK_INT >= 33) {
            card("Yaxın Wi-Fi cihazları", checkSelfPermissionCompat("android.permission.NEARBY_WIFI_DEVICES") ? "İcazə verilib" : "İcazə verilməyib", null);
            card("Bildirişlər", checkSelfPermissionCompat("android.permission.POST_NOTIFICATIONS") ? "İcazə verilib" : "İcazə verilməyib", null);
        }
        card("Monitor", Build.MANUFACTURER + " " + Build.MODEL, "Android " + Build.VERSION.RELEASE + "  •  API " + Build.VERSION.SDK_INT);
        card("Tətbiq", getPackageName(), "VOOBAX Drive — ayrıca paket identifikatoru");

        latestReport = "VOOBAX Drive diaqnostikası\nWi-Fi: " + wifi + "\nŞəbəkə: " + details
            + "\nBluetooth: " + bt + "\nMikrofon: " + mic + "\nMəkan: " + loc
            + "\nMonitor: " + Build.MANUFACTURER + " " + Build.MODEL
            + "\nAndroid: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")";
        TextView actions = label("SÜRƏTLİ AYARLAR", 16, SECONDARY, true);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2); ap.setMargins(0, dp(12), 0, dp(10)); root.addView(actions, ap);
        action("Wi-Fi ayarları", Settings.ACTION_WIFI_SETTINGS);
        action("Bluetooth ayarları", Settings.ACTION_BLUETOOTH_SETTINGS);
        action("Məkan ayarları", Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        action("Tətbiq icazələri", Settings.ACTION_APPLICATION_DETAILS_SETTINGS); // handled specially below
        Button copy = new Button(this); copy.setAllCaps(false); copy.setText("Diaqnostika hesabatını kopyala");
        root.addView(copy, new LinearLayout.LayoutParams(-1, dp(52)));
        copy.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("VOOBAX Diaqnostika", latestReport));
            Toast.makeText(DiagnosticsActivity.this, "Hesabat kopyalandı", Toast.LENGTH_SHORT).show();
        }});
        TextView foot = label("Təhlükəsizlik üçün avtomobil dayanarkən ayarları dəyişin.", 12, SECONDARY, false);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2); fp.setMargins(0, dp(18), 0, 0); root.addView(foot, fp);
    }
    private boolean checkSelfPermissionCompat(String permission) {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }
}
