# VOOBAX Drive

Azərbaycan dilində, ayrıca quraşdırılan Android Auto qəbuledicisi. `com.voobax.drive` identifikatoru ilə Open Headunit-dən ayrı quraşdırılır. **CarPlay dəstəklənmir.**

Open Headunit v.3.5.0 əsasında AGPL-3.0 fork: https://github.com/andreknieriem/open-headunit/tree/1c1b5b7261ebebde8000778ff2c06e3af3e3a326

Bu repozitoriya sabit upstream commit-i və açıq dəyişiklik dəstini saxlayır. Actions həmin tam mənbəni endirir, dəyişiklikləri tətbiq edir və `:app:assembleGithubDebug` qurur. Başqa Open Headunit/ZLINK/AutoKit tətbiqinin ayrıca quraşdırılması tələb edilmir; cihaz uyğunluğu real sınaq tələb edir.

## Yükləmə və yoxlama

[Actions yığımları](https://github.com/voobaxapps/VOOBAX-DRIVE/actions/workflows/build-apk.yml) → uğurlu run → `VOOBAX-Drive-debug-APK`. Artefaktda APK, ölçü, SHA-256 və manifest məlumatı olur. Yalnız yaşıl yığımın artefaktını yükləyin. APK debug imzası ilədir. Eyni yığımın tam dəyişdirilmiş mənbəsi `VOOBAX-Drive-corresponding-source` artefaktındadır.

İlk simsiz qoşulmadan əvvəl telefonda Android Auto, Bluetooth və Wi-Fi aktiv olmalıdır. Monitorla telefonu cütləşdirin; tətbiqin quraşdırma ekranında tələb olunan mikrofon, məkan, yaxın cihazlar və bildiriş icazələrini verin. Uyğun cihazda Native Wireless rejimini seçin və telefondakı Android Auto təsdiqini tamamlayın. USB və digər upstream bağlantı rejimləri saxlanır. Diaqnostika eyni APK-də ayrıca girişdir və lokal məlumat göstərir; hesabat yalnız düyməyə basıldıqda mübadilə buferinə köçürülür.

## Təkrarlanan yığım

JDK 17, Android SDK 36, upstream Gradle-də göstərilən NDK və CMake 3.22.1 tələb olunur:

```sh
git clone https://github.com/andreknieriem/open-headunit.git upstream
git -C upstream checkout 1c1b5b7261ebebde8000778ff2c06e3af3e3a326
python3 -m unittest discover -s tests -v
python3 apply_voobax.py upstream
cd upstream
chmod +x gradlew
./gradlew :app:assembleGithubDebug
```

Patch yalnız təmiz checkout-a bir dəfə tətbiq olunur. Java/Kotlin namespace saxlanır; applicationId, köhnə tətbiq identifikatoruna istinadlar və imza ilə qorunan naviqasiya icazəsi ayrılır. Azərbaycan dili əsas mətnlərə tətbiq edilir; tərcüməsi olmayan mətnlər upstream dilində qalır. Format parametrləri uyğun gəlməyən tərcümələr tətbiq edilmir; plurals və mətn daxilində XML işarələməsi saxlanır. Qaranlıq əsas mövzu və VOOBAX ikonu əlavə edilir. USB, Wi-Fi Direct/hotspot, təkrar qoşulma, video və audio mühərriki upstream-dən saxlanır.

## Hüquqlar və sınaq məhdudiyyətləri

GNU AGPL-3.0; [LICENSE](LICENSE). Michael A. Reid, Andre Knieriem və upstream iştirakçılarının müəllif hüquqları və bildirişləri saxlanır. VOOBAX əlavələri AGPL-3.0-only ilədir. Dəyişikliklər `apply_voobax.py`, `translations_az.json` və `overlay/` daxilində açıqdır. Mənbə əldə etmə ünvanı bu public repozitoriyadır. Tam müvafiq mənbəni APK ilə birlikdə paylaşın. Android Auto Google-un ticarət nişanıdır; rəsmi Google və ya Apple məhsulu deyil.

Python testləri Android kompilyasiyasını və ya real Android Auto bağlantısını təsdiqləmir. Real avtomobil sınağı aparılmayıb; ayarları yalnız avtomobil dayanarkən dəyişin. Yığım nəticəsi Actions səhifəsində yoxlanmalıdır.
