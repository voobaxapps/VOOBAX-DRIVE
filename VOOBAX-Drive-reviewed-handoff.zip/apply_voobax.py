#!/usr/bin/env python3
"""Apply VOOBAX-branded Azerbaijani resource layer to Open Headunit v.3.5.0.

This script is NOT a standalone Android Auto implementation. It patches the real upstream
Android Auto receiver; the output requires the upstream source tree and Android SDK to build.
Project attribution and AGPL licensing remain with the source.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import shutil
import sys
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

ROOT = Path(__file__).resolve().parent
OLD_ID = "com.andrerinas.headunitrevived"
NEW_ID = "com.voobax.drive"


def replace_exact(path: Path, before: str, after: str, required: bool = True) -> bool:
    data = path.read_text(encoding="utf-8")
    if before not in data:
        if required:
            raise RuntimeError(f"Expected text not found in {path}: {before[:120]}")
        return False
    path.write_text(data.replace(before, after), encoding="utf-8")
    return True


def android_text(value: str) -> str:
    return escape(value).replace("'", "\\'").replace('"', '\\"')


def formats(value: str) -> list[str]:
    return sorted(re.findall(r'%(?:\d+\$)?[-#+ 0,(]*\d*(?:\.\d+)?[a-zA-Z]', value))


def localize(res: Path, translations: dict[str, str]) -> int:
    original = res / "values" / "strings.xml"
    if not original.exists():
        raise RuntimeError("Open Headunit original values/strings.xml not found")
    text = original.read_text(encoding="utf-8")
    ET.fromstring(text)  # Validate XML BEFORE editing.
    found: dict[str, str] = {}
    # Preserve existing resource layout and every unmodified string.
    # Only single, text-only <string> resources with verified names are overwritten.
    for key, az in translations.items():
        pat = re.compile(r'(<string\s+[^>]*?name="' + re.escape(key) + r'"[^>]*>)(.*?)(</string>)', re.S)
        match = pat.search(text)
        if not match or '<' in match.group(2) or formats(match.group(2)) != formats(az):
            continue
        text = pat.sub(lambda m: m.group(1) + android_text(az) + m.group(3), text, count=1)
        found[key] = az
    for key in ("title", "app_name"):
        if key not in found:
            # Do not insert duplicate resources when app name is in another file.
            present_anywhere = any(re.search(r'<string\s+[^>]*?name="' + key + '"', p.read_text(encoding='utf-8'))
                for p in (res / 'values').glob('*.xml'))
            if not present_anywhere:
                text = text.replace('</resources>', f'    <string name="{key}">VOOBAX Drive</string>\n</resources>')
                found[key] = 'VOOBAX Drive'
    text = text.replace('</resources>', '    <string name="voobax_diagnostics">VOOBAX Diaqnostika</string>\n</resources>')
    ET.fromstring(text)
    original.write_text(text, encoding='utf-8')
    azdir = res / 'values-az'; azdir.mkdir(parents=True, exist_ok=True)
    rows = ['<?xml version="1.0" encoding="utf-8"?>', '<resources>']
    rows.extend(f'    <string name="{key}">{android_text(value)}</string>' for key, value in found.items())
    rows.append('    <string name="voobax_diagnostics">VOOBAX Diaqnostika</string>')
    rows.append('</resources>')
    result = '\n'.join(rows) + '\n'
    ET.fromstring(result)
    (azdir / 'strings.xml').write_text(result, encoding='utf-8')
    # Locale selection must never restore the upstream launcher name.
    for file in res.glob('values*/strings.xml'):
        data = file.read_text(encoding='utf-8')
        for key in ('title', 'app_name'):
            data = re.sub(r'(<string\s+[^>]*name="' + key + r'"[^>]*>).*?(</string>)',
                          lambda m: m.group(1) + 'VOOBAX Drive' + m.group(2), data, flags=re.S)
        file.write_text(data, encoding='utf-8')
    return len(found)


def apply(src: Path) -> None:
    src = src.resolve()
    app = src / 'app'
    gradle = app / 'build.gradle.kts'
    manifest = app / 'src/main/AndroidManifest.xml'
    res = app / 'src/main/res'
    for required in (gradle, manifest, res / 'values/strings.xml', src / 'LICENSE'):
        if not required.exists():
            raise RuntimeError(f"Not an Open Headunit source tree: {required} missing")

    if (res / 'values-az/strings.xml').exists():
        raise RuntimeError('Source already patched; use a clean upstream checkout')

    original_gradle = gradle.read_text(encoding='utf-8')
    if 'versionName = "3.5.0"' not in original_gradle and 'versionName = "1.0.0-voobax"' not in original_gradle:
        raise RuntimeError('Project version differs from verified v.3.5.0. Aborting to avoid breaking a newer version.')
    replace_exact(gradle, f'applicationId = "{OLD_ID}"', f'applicationId = "{NEW_ID}"', required=True)
    replace_exact(gradle, 'versionName = "3.5.0"', 'versionName = "1.0.0-voobax"', required=False)

    translations = json.loads((ROOT / 'translations_az.json').read_text(encoding='utf-8'))
    count = localize(res, translations)

    # Resource and internal source constants (not Kotlin/Java package paths) must match the new appId.
    total_replaced = 0
    for file in (app / 'src').rglob('*'):
        if file.suffix in ('.xml', '.kt', '.java', '.json') and file.is_file():
            old = file.read_text(encoding='utf-8')
            if OLD_ID in old or 'com.andrerinas.openheadunit.permission.NAVIGATION_UPDATE' in old:
                file.write_text(old.replace(OLD_ID, NEW_ID).replace('com.andrerinas.openheadunit.permission.NAVIGATION_UPDATE', NEW_ID + '.permission.NAVIGATION_UPDATE'), encoding='utf-8')
                total_replaced += 1

    styles = res / 'values/styles.xml'
    if styles.exists():
        replace_exact(styles, 'Theme.Material3.DayNight.NoActionBar', 'Theme.Material3.Dark.NoActionBar')

    # Put diagnostics INSIDE the same APK, with its own optional launch entry.
    destination = app / 'src/main/java/com/voobax/drive'
    destination.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / 'overlay/java/com/voobax/drive/DiagnosticsActivity.java', destination / 'DiagnosticsActivity.java')
    label = '@string/voobax_diagnostics'
    diagnostic_activity = f'''\n        <!-- VOOBAX add-on: local-only device diagnostics -->
        <activity android:name="com.voobax.drive.DiagnosticsActivity"
            android:label="{label}"
            android:exported="true"
            android:theme="@style/AppTheme">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>\n'''
    m = manifest.read_text(encoding='utf-8')
    if 'com.voobax.drive.DiagnosticsActivity' not in m:
        if '</application>' not in m:
            raise RuntimeError('No </application> in AndroidManifest.xml')
        m = m.replace('</application>', diagnostic_activity + '</application>')
    # Replace ONLY app-wide launcher icon. Activity retains its original theme/layout.
    m = m.replace('android:icon="@mipmap/ic_launcher"', 'android:icon="@mipmap/ic_voobax"')
    ET.fromstring(m)
    manifest.write_text(m, encoding='utf-8')

    sourceicons = ROOT / 'overlay/icons'
    for icon in sourceicons.iterdir():
        if not icon.is_dir(): continue
        todir = res / icon.name; todir.mkdir(parents=True, exist_ok=True)
        for item in icon.iterdir():
            shutil.copy2(item, todir / item.name)

    # Keep upstream AGPL and copyright, add a clear derivative-app attribution.
    (src / 'VOOBAX_DERIVATIVE_LICENSE.txt').write_text('''VOOBAX Drive 1.0.0: an independent, modified application based on Open Headunit v.3.5.0.
Upstream authors: Michael A. Reid and Andre Knieriem + other contributors.
Upstream: https://github.com/andreknieriem/open-headunit
Upstream license: GNU Affero General Public License v3, see LICENSE and COPYRIGHT_MICHAEL_REID_GPLv3AFFERO.txt.
All upstream notices, author credits and source availability requirements must be retained.
The VOOBAX localizations and diagnostics add-on are published under AGPL-3.0-only.
Android Auto is a Google trademark. No affiliation with Google or Apple is implied.
VOOBAX Drive is NOT an Apple CarPlay receiver.\n''', encoding='utf-8')
    print(f'VOOBAX patch applied. Localized strings: {count}; appID constants in files: {total_replaced}')
    print('Build using: ./gradlew :app:assembleGithubDebug')
    print('Output: app/build/outputs/apk/github/debug/*.apk (actual name varies)')

if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='Rebrand upstream Open Headunit v3.5.0 for VOOBAX Drive')
    ap.add_argument('source_tree', help='Path to checked-out upstream Open Headunit v.3.5.0')
    args = ap.parse_args()
    try: apply(Path(args.source_tree))
    except Exception as e:
        print('ERROR:', e, file=sys.stderr)
        sys.exit(1)
